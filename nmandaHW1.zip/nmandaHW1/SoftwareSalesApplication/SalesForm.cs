﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareSalesApplication
{
    public partial class SalesForm : Form
    {
        public SalesForm()
        {
            InitializeComponent();
        }

        private void SalesForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void setupDatePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        int custID = 0;
        String custName = null;
        int nooflicence = 0;
        String setupDate;
        String traingDate;
        int swpkgprice=0;

        private void salesbtn_Click(object sender, EventArgs e)
        {
            custID = int.Parse(customerIDTB.Text);
            custName = cnameTB.Text.ToString();
            nooflicence = int.Parse(nooflicenceTB.Text);
            
            if( swpkgLB.Equals("Sales Management"))
           {
               swpkgprice = 2000;
                
           }
            if (swpkgLB.Equals("BackUp Manager"))
            {
                swpkgprice = 800;

            }
            if (swpkgLB.Equals("Payroll Solutions"))
            {
                swpkgprice = 4500;
            }
            if (swpkgLB.Equals("EasyMeeting"))
            {
                swpkgprice = 1000;
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (addsetupchkbox.Checked==true)
            {
                setupDatePicker.Enabled = true;
                setupDatePicker.Visible = true;
            }
            if (addsetupchkbox.Checked==false)
            {
                setupDatePicker.Enabled = false;
                setupDatePicker.Visible = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            if (addtrainchkbox.Checked == true)
            {
                trainingDatepicker.Enabled = true;
                trainingDatepicker.Visible = true;
            }
            if (addtrainchkbox.Checked == false)
            {
                trainingDatepicker.Enabled = false;
                trainingDatepicker.Visible = false;
            }
        }

        private void swpkgLB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
