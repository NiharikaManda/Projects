﻿using System;

namespace SoftwareSalesApplication
{
    public class Training : IService
    {
        public string customerName { set; get; }
        public string dateOfService { set; get; }
        public double serviceCharge { set; get; }
        public string softwareName { set; get; }
        public int trainingFee { set; get; }

        //  parameterized constructor
        public Training(string cName, string dofService, string propSoftware, double scharge, int ntrainingFee)
{
            serviceCharge = scharge;
softwareName = propSoftware;
dateOfService = dofService;
trainingFee = ntrainingFee;
customerName= cName;
}
    }
}
