﻿//Homework Assignment1
//Developer:Niharika Manda
using System;
using System.Collections;
using System.Windows.Forms;

namespace SoftwareSalesApplication
{
    public partial class purchaseSoftware : Form
    {

        SoftwareSale softwareSales;
        Training train;
        Setup setup ;
        //arraylist initialization 
        ArrayList salesList = new ArrayList();
        ArrayList setupOrder = new ArrayList();
        ArrayList trainingRequest = new ArrayList();
        int sales_transactions = 0;

        public purchaseSoftware()
        {
            InitializeComponent();
        }

        
        private void SalesForm_Load(object sender, EventArgs e)
        {

        }

        bool IsAllAlphabetic(string value)
        {
            foreach (char c in value)
            {
                if (!char.IsLetter(c))
                    return false;

            }

            return true;
        }

        bool IsNumber(string value)
        {
            foreach (char c in value)
            {
                if (!char.IsLetter(c))
                    return false;

            }

            return true;
        }

        int custID = 0;
        String custName;
        int nooflicence = 0;
        String setupDate;
        String traingDate;
        int swpkgprice = 0;
        int licenseCost;
        int setUpFee = 0;
        double totalCharge = 0;
        int trainFee = 0;
        int setupFee = 0;
        string orderDate;
        string softWare;
        private void salesbtn_Click(object sender, EventArgs e)
        {
            saleslistbx.Items.Clear();

            string setupOption = "NO";
            string trainingOption = "NO";
            
            try
            {
                if (!IsAllAlphabetic(cnameTB.Text))
                {
                    throw new Exception();


                }
                else
                    if ((IsNumber(nooflicenceTB.Text)) && (IsNumber(customerIDTB.Text)))
                    {
                        throw new Exception();
                    }
            }

            catch (NullReferenceException ex)
        {
           
                MessageBox.Show(ex.Message);
            }
            // validating the setup and training checkboxes
            if (addsetupchkbox.Checked == true)

















            {
                setupOption = "YES";
            }
            if (addtrainchkbox.Checked == true)
            {
                trainingOption = "YES";
                     
            }

            try
            {
            softwareSales = new SoftwareSale(softWare, int.Parse(nooflicenceTB.Text), setupOption, trainingOption, Convert.ToInt32(customerIDTB.Text), cnameTB.Text, DateTime.Now.ToString());

            orderDate = setupDatePicker.Text.ToString();
            traingDate = trainingDatepicker.Text.ToString();
            
                softWare = (Convert.ToString(swpkgLB.SelectedItem));

            }
            catch (Exception err)
            {
                 MessageBox.Show(err.Message, "Exception:In converting the values");
            }
            



            // handling the exceptions
            try
            {

                if (swpkgLB.SelectedItem.Equals("Sales Management"))
                {
                    swpkgprice = 2000;

                    licenseCost = (softwareSales.numberOfLicenses) * swpkgprice;
                    setUpFee = 500 * (softwareSales.numberOfLicenses);
                    trainFee = 2000;

                }
                if (swpkgLB.SelectedItem.Equals("BackUp Manager"))
                {
                    swpkgprice = 800;
                    licenseCost = softwareSales.numberOfLicenses * swpkgprice;
                    setUpFee = 500 * softwareSales.numberOfLicenses;
                    trainFee = 1000;
                }
                if (swpkgLB.SelectedItem.Equals("Payroll Solutions"))
                {
                    swpkgprice = 4500;
                    licenseCost = softwareSales.numberOfLicenses * swpkgprice;
                    setUpFee = 500 * softwareSales.numberOfLicenses;
                    trainFee = 2000;
                }
                if (swpkgLB.SelectedItem.Equals("EasyMeeting"))
                {

                    swpkgprice = 1000;
                    licenseCost = softwareSales.numberOfLicenses * swpkgprice;
                    setUpFee = 500 * softwareSales.numberOfLicenses;
                    trainFee = 1000;
                }
                // calculating the charge

                softwareSales.calculate(swpkgprice, licenseCost, setUpFee, trainFee);

                if (addsetupchkbox.Checked == true)
                {
                    setupOption = "YES";
                    setup = new Setup(cnameTB.Text.ToString(), setupDatePicker.Value.ToString(), softWare, (double)setUpFee, softwareSales.numberOfLicenses);
                    setupOrder.Add(setup);
                }
                if (addtrainchkbox.Checked == true)
                {
                    trainingOption = "YES";
                    train = new Training(cnameTB.Text.ToString(), trainingDatepicker.Value.ToString(), softWare, (double)trainFee, trainFee);
                    trainingRequest.Add(train);

                }

                salesList.Add(softwareSales);
                saleslistbx.Items.Add("Customer Name: " + softwareSales.customerName + "  " + " Order Date" + softwareSales.transactiondDate + "   " + "Software Package: " + softWare + "  " + "Total charge: " + softwareSales.totalCharges + "  SetupFee: " + setUpFee + " TrainingFee: " + trainFee + "   " + "Charge:" + licenseCost);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Please enter the valid format");
            }
            

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (addsetupchkbox.Checked == true)
            {
                setupDatePicker.Enabled = true;
                setupDatePicker.Visible = true;
            }
            if (addsetupchkbox.Checked == false)
            {
                setupDatePicker.Enabled = false;
                setupDatePicker.Visible = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            if (addtrainchkbox.Checked == true)
            {
                trainingDatepicker.Enabled = true;
                trainingDatepicker.Visible = true;
            }
            if (addtrainchkbox.Checked == false)
            {
                trainingDatepicker.Enabled = false;
                trainingDatepicker.Visible = false;
            }
        }

       
        private void button1_Click(object sender, EventArgs e)
        {

            saleslistbx.Items.Clear();

           foreach (SoftwareSale someSales in salesList)


               saleslistbx.Items.Add("Customer Name:  " + someSales.customerName + " Software: " + softWare + " Setup Option: " + someSales.setupOption + " Training Option: " + someSales.trainingOption + " Date of Sales Transaction: " +someSales.transactiondDate);
            


        }

        private void button2_Click(object sender, EventArgs e)
        {
            saleslistbx.Items.Clear();

            foreach (Setup someSetup in setupOrder)


                saleslistbx.Items.Add("Customer Name:  " + someSetup.customerName + " Setup Date: " + someSetup.dateOfService + " Software: " + someSetup.propSoftwareName + " Number of Licenses: " + someSetup.numberOfLicense);
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            saleslistbx.Items.Clear();

            foreach (Training someTraining in trainingRequest)


                saleslistbx.Items.Add("Customer Name:  " + someTraining.customerName + " training Date: " + someTraining.dateOfService + " Software: " + someTraining.softwareName);
            
        }

        private void customerIDTB_TextChanged(object sender, EventArgs e)
        {

        }

        }
    }

