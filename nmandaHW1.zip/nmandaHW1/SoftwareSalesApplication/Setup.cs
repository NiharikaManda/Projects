﻿using System;

namespace SoftwareSalesApplication
{
    public class Setup : IService
    {
        public string customerName { set; get; }

        public int numberOfLicense { set; get; }
        
        public string propSoftwareName { set; get; }

        public double serviceCharge { set; get; }

        public string dateOfService { set; get; }
        
        // parameterized constructor
public Setup(string cName,string dofService,string propSoftware,double scharge,int nLicense)
{
    serviceCharge = scharge;
propSoftwareName = propSoftware;
dateOfService = dofService;
numberOfLicense = nLicense;
customerName= cName;
}


    }
}
