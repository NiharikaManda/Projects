﻿namespace SoftwareSalesApplication
{
    partial class SalesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customerIDTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cnameTB = new System.Windows.Forms.TextBox();
            this.nooflicenceTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.swpkgLB = new System.Windows.Forms.ListBox();
            this.addsetupchkbox = new System.Windows.Forms.CheckBox();
            this.addtrainchkbox = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.setupDatePicker = new System.Windows.Forms.DateTimePicker();
            this.trainingDatepicker = new System.Windows.Forms.DateTimePicker();
            this.processsalesbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // customerIDTB
            // 
            this.customerIDTB.Location = new System.Drawing.Point(118, 45);
            this.customerIDTB.Name = "customerIDTB";
            this.customerIDTB.Size = new System.Drawing.Size(100, 20);
            this.customerIDTB.TabIndex = 0;
            this.customerIDTB.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Customer ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // cnameTB
            // 
            this.cnameTB.Location = new System.Drawing.Point(118, 88);
            this.cnameTB.Name = "cnameTB";
            this.cnameTB.Size = new System.Drawing.Size(100, 20);
            this.cnameTB.TabIndex = 2;
            // 
            // nooflicenceTB
            // 
            this.nooflicenceTB.Location = new System.Drawing.Point(118, 120);
            this.nooflicenceTB.Name = "nooflicenceTB";
            this.nooflicenceTB.Size = new System.Drawing.Size(100, 20);
            this.nooflicenceTB.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Customer Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "NumberOfLicence";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // swpkgLB
            // 
            this.swpkgLB.FormattingEnabled = true;
            this.swpkgLB.Items.AddRange(new object[] {
            "Sales Management",
            "BackUp Manager",
            "Payroll Solutions",
            "EasyMeeting"});
            this.swpkgLB.Location = new System.Drawing.Point(118, 171);
            this.swpkgLB.Name = "swpkgLB";
            this.swpkgLB.Size = new System.Drawing.Size(155, 56);
            this.swpkgLB.TabIndex = 7;
            // 
            // addsetupchkbox
            // 
            this.addsetupchkbox.AutoSize = true;
            this.addsetupchkbox.Location = new System.Drawing.Point(118, 232);
            this.addsetupchkbox.Name = "addsetupchkbox";
            this.addsetupchkbox.Size = new System.Drawing.Size(76, 17);
            this.addsetupchkbox.TabIndex = 8;
            this.addsetupchkbox.Text = "Add Setup";
            this.addsetupchkbox.UseVisualStyleBackColor = true;
            this.addsetupchkbox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // addtrainchkbox
            // 
            this.addtrainchkbox.AutoSize = true;
            this.addtrainchkbox.Location = new System.Drawing.Point(118, 283);
            this.addtrainchkbox.Name = "addtrainchkbox";
            this.addtrainchkbox.Size = new System.Drawing.Size(86, 17);
            this.addtrainchkbox.TabIndex = 9;
            this.addtrainchkbox.Text = "Add Training";
            this.addtrainchkbox.UseVisualStyleBackColor = true;
            this.addtrainchkbox.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Software Packages";
            // 
            // setupDatePicker
            // 
            this.setupDatePicker.Enabled = false;
            this.setupDatePicker.Location = new System.Drawing.Point(250, 232);
            this.setupDatePicker.Name = "setupDatePicker";
            this.setupDatePicker.Size = new System.Drawing.Size(200, 20);
            this.setupDatePicker.TabIndex = 13;
            this.setupDatePicker.Visible = false;
            this.setupDatePicker.ValueChanged += new System.EventHandler(this.setupDatePicker_ValueChanged);
            // 
            // trainingDatepicker
            // 
            this.trainingDatepicker.Enabled = false;
            this.trainingDatepicker.Location = new System.Drawing.Point(250, 278);
            this.trainingDatepicker.Name = "trainingDatepicker";
            this.trainingDatepicker.Size = new System.Drawing.Size(200, 20);
            this.trainingDatepicker.TabIndex = 14;
            this.trainingDatepicker.Visible = false;
            this.trainingDatepicker.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // processsalesbtn
            // 
            this.processsalesbtn.Location = new System.Drawing.Point(118, 324);
            this.processsalesbtn.Name = "processsalesbtn";
            this.processsalesbtn.Size = new System.Drawing.Size(98, 23);
            this.processsalesbtn.TabIndex = 15;
            this.processsalesbtn.Text = "Process Sale";
            this.processsalesbtn.UseVisualStyleBackColor = true;
            this.processsalesbtn.Click += new System.EventHandler(this.salesbtn_Click);
            // 
            // SalesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 403);
            this.Controls.Add(this.processsalesbtn);
            this.Controls.Add(this.trainingDatepicker);
            this.Controls.Add(this.setupDatePicker);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.addtrainchkbox);
            this.Controls.Add(this.addsetupchkbox);
            this.Controls.Add(this.swpkgLB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nooflicenceTB);
            this.Controls.Add(this.cnameTB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.customerIDTB);
            this.Name = "SalesForm";
            this.Text = "SoftwareSalesForm";
            this.Load += new System.EventHandler(this.SalesForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox customerIDTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox cnameTB;
        private System.Windows.Forms.TextBox nooflicenceTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox swpkgLB;
        private System.Windows.Forms.CheckBox addsetupchkbox;
        private System.Windows.Forms.CheckBox addtrainchkbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker setupDatePicker;
        private System.Windows.Forms.DateTimePicker trainingDatepicker;
        private System.Windows.Forms.Button processsalesbtn;
    }
}

