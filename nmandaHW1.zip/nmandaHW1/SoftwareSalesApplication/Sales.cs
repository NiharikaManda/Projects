﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareSalesApplication
{
   public class Sales
    {
        public int customerID{set;get;}
        public string customerName{set;get;}
        public string transactiondDate{set;get;}
        public double totalCharges = 0; 
        public double calculate(int swpkgprice, int licenseCost, int setUpFee, int trainingFee)
        {
            totalCharges = swpkgprice+licenseCost+setUpFee+trainingFee;
            return totalCharges;
        }
        public Sales(int id, string Name, string date)
        {
            customerID= id;
            customerName = Name;
            transactiondDate= date;
        }
    }
}
