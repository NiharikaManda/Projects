﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareSalesApplication 

{
    public class SoftwareSale : Sales
    {
       public string softwareName{set;get;}
        public int numberOfLicenses{set;get;}
       public string setupOption{set;get;}
       public string trainingOption { set; get; } 
        
        public SoftwareSale( string sName, int nLicense,string setOption, string trainOption,int custId, string custName,string tDate)
           : base(custId, custName, tDate)
       {
           softwareName=  sName;
           numberOfLicenses = nLicense;
           setupOption = setOption;
           trainingOption = trainOption;

        }
    }
}
