﻿namespace SoftwareSalesApplication
{
    interface IService
    {
        string customerName { set; get; }
        string dateOfService { set; get; }
        double serviceCharge { set; get; }

    }
}
